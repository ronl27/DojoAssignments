#landing page checklist

1. Files that I need
+ 'index.html'
+ 'ninjas.html'
+ 'dojo.html'
+ 'server.js'

2. Write the HTML for my static page

3. Build the Node server:
1. 'require' my dependencies:
+ 'fs'
+ 'http'
2. Create and run the server
3. Figure out which file the HTTP request is looking for
4. Read and send the file to the browser (if the file/url does not exist, send a '404' w/ 'File not found!' message)
